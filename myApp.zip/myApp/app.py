from flask import Flask,render_template,request,session,logging,url_for,redirect,flash
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session,sessionmaker
import pymysql
from passlib.hash import sha256_crypt
engine = create_engine("mysql+pymysql://root:@localhost/pyAssign")
db = scoped_session(sessionmaker(bind=engine))
app = Flask(__name__)

@app.route('/')
def home():
    return render_template("home.html")

#register form

@app.route("/register",methods=["GET","POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name")
        username = request.form.get("username")
        mail = request.form.get("mail")
        dob = request.form.get("dob")
        password = request.form.get("pwd")
        confirm = request.form.get("confirm")
        secure_password = sha256_crypt.encrypt(str(password))

        if password == confirm:
            db.execute("insert into users(name,username,mail,dob,password) values (:name,:username,:mail,:dob,:password)",
                   {"name":name,"username":username,"mail":mail,"dob":dob,"password":secure_password})
            db.commit()
            flash("You are registered successfully and you can login","success")
            return redirect(url_for('login'))
        else:
            flash("Password does not match","danger")
            return render_template("register.html")           

    return render_template("register.html")

#login form

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method == "POST":
        mail = request.form.get("mail")
        password = request.form.get("password")
        maildata = db.execute("select mail from users where mail=:mail",{"mail":mail}).fetchone()
        passwordata = db.execute("select password from users where mail=:mail",{"mail":mail}).fetchone()

        if maildata is None:
            flash("No email","danger")
            return render_template("login.html")
        else:
            for passwor_data in passwordata:
                if sha256_crypt.verify(password,passwor_data):
                    session["log"] = True

                    flash("You are login now","success")
                    return redirect(url_for('photo'))
                else:
                    flash("Incorrect password","danger")
                    return render_template("login.html")

    return render_template("login.html")

#photo
@app.route("/photo")
def photo():
    return render_template("photo.html")

#logout
@app.route("/logout")
def logout():
    session.clear()
    flash("You are now logout","success")
    return redirect(url_for('login'))

if __name__ =="__main__":
    app.secret_key="whoami777"
    app.run(debug=True)