-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 22, 2020 at 07:10 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pyAssign`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(25) DEFAULT NULL,
  `username` varchar(25) DEFAULT NULL,
  `mail` varchar(50) DEFAULT NULL,
  `dob` varchar(25) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `mail`, `dob`, `password`) VALUES
(8, 'Neeraj kumar', 'kumar', 'asnaa@palos.com', '06/06/1992', '$5$rounds=535000$xJtK9IOpk4UjNksk$PWrGdlqAgha4RjZHZL8HdAXdxfaJO3ix6OK6Cumcsa2'),
(9, 'Rohan kumar', 'rohan', 'rohan@gmail.com', '06/06/1992', '$5$rounds=535000$nHVZtTdqM4o1cb29$oDlvqGnXPBwa6cCle9.XJoRHZy1Oo9l5GKGcwR7Hpq7'),
(10, 'Demo demo', 'demooo', 'demo@palos.com', '06/06/1992', '$5$rounds=535000$KfJVXd4zXdM/Mglu$r.U9lYhFONCLgquRDxaYkRAYVQ3pg.Y4.I3YKreZvp9'),
(11, 'awdrt.net', 'jdbxjjbbmxbrzvqoiz', NULL, '2000-12-30', '$5$rounds=535000$n6VDx3ZlLWhN6rzf$FGWhVAWfTeTIXo2EF62KpgX/OqQoVL6k8qwrfTiYv3.'),
(12, 'awdrt.net', 'jdbxjjbbmxbrzvqoiz', NULL, '2000-12-30', '$5$rounds=535000$WthzfDY8U8WGlXdm$bZmsnYfg0m0OEodjRUh8jt.XQUzik3fAeyKoWGgNHo0'),
(13, 'awdrt.net', 'jdbxjjbbmxbrzvqoiz', NULL, '2000-12-30', '$5$rounds=535000$s8StC4S8n8W/DDS3$QNtVeee6To0Ct7gAeyIsd0Xdx.ZJLR1qq99JQNMFmW.'),
(14, 'awdrt.net', 'jdbxjjbbmxbrzvqoiz', NULL, '2000-12-30', '$5$rounds=535000$Ig32vfW15DsWNiua$NMAJU63tQXBy5axtlGktfaCpUC8cNUsYu5OmApTIvrB'),
(15, 'awdrt.net', 'jdbxjjbbmxbrzvqoiz', NULL, '2000-12-30', '$5$rounds=535000$8ibTwj/LYSfFnf3F$Vt7GW8/IX907kvr/pstpso0xVS9IVj8MKDNNFw/oYEA'),
(16, 'awdrt.net', 'jdbxjjbbmxbrzvqoiz', NULL, '2000-12-30', '$5$rounds=535000$Ksz51Mn7BlXY0VMG$7RsUWZFMGqvHQrerdxoBCgIODPNChUbaawIKeqBlT55'),
(17, 'awdrt.net', 'jdbxjjbbmxbrzvqoiz', NULL, '2000-12-30', '$5$rounds=535000$fw7EY03sGU17.rLH$WENSqQO2oMtTZquWa1vpLVYsJhNdUsiv3/5oTQ23e34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
