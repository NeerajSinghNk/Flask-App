from flask import Flask,render_template,request,session,logging,url_for,redirect,flash
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session,sessionmaker
import pymysql
from passlib.hash import sha256_crypt
from functools import wraps
engine = create_engine("mysql+pymysql://root:Neerajkumar@1237@localhost/pyAssign")
db = scoped_session(sessionmaker(bind=engine))
app = Flask(__name__)
app.config['SECRET_KEY'] = "whoami777@1237neeraj@cyber"

@app.route('/')
def home():
    
    return render_template("home.html")

#register form

@app.route("/register",methods=["GET","POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name")
        username = request.form.get("username")
        mail = request.form.get("mail")
        dob = request.form.get("dob")
        password = request.form.get("pwd")
        confirm = request.form.get("confirm")
        secure_password = sha256_crypt.encrypt(str(password))
        count = ""
        count = db.execute("select mail from users where mail=:mail",{"mail":mail}).fetchone()
       
        if count is not None:
            flash("This email already taken,please choose another one...","danger")
            return render_template("register.html")

        elif count is None:
            if password == confirm:
                db.execute("insert into users(name,username,mail,dob,password) values (:name,:username,:mail,:dob,:password)",
                    {"name":name,"username":username,"mail":mail,"dob":dob,"password":secure_password})
                db.commit()
                #db.close()
                flash("You are registered successfully and you can login","success")
                return redirect(url_for('login'))
            else:
                flash("Password does not match","danger")
                return render_template("register.html")           

    return render_template("register.html")

#login form

@app.route("/profile",methods=["GET","POST"])
def login():
    if request.method == "POST":
        mail = request.form.get("mail")
        password = request.form.get("password")
        maildata = db.execute("select mail from users where mail=:mail",{"mail":mail}).fetchone()
        passwordata = db.execute("select password from users where mail=:mail",{"mail":mail}).fetchone()

        if maildata is None:
            flash("No email","danger")
            return render_template("login.html")
        else:
            for passwor_data in passwordata:
                if sha256_crypt.verify(password,passwor_data):
                    session["logged_in"] = True
                    session["mail"] = mail
                    flash("You are login now","success")
                    return redirect("dashboard")
 
                else:
                    flash("Incorrect password","danger")
                    return render_template("login.html")

    return render_template("login.html")

# Check if user logged in
def is_logged_in(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash('Unauthorized, Please login', 'danger')
            return redirect(url_for('login'))
    return wrap

#dashboard
@app.route("/dashboard")
@is_logged_in
def dashboard():

    mail = [session["mail"]]
    user = db.execute("select * from users where mail=:mail",{"mail":mail}).fetchone()
    
    return render_template("dashboard.html", user=user)

#logout
@app.route("/logout")
@is_logged_in
def logout():
    session.clear()
    flash("You are now logout","success")
    return redirect(url_for('login'))

if __name__ =="__main__":
    app.run(debug=True)